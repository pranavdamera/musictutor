# Bansuri AI Tuner

This project aims to develop an AI-powered pitch correction app for the bansuri flute.